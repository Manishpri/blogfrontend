export class Blogpost {
    id: number;
    title: string;
    
    author: string;
    

}
