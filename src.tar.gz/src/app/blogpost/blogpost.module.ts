import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BlogpostRoutingModule } from './blogpost-routing.module';
import { BlogpostComponent } from './blogpost/blogpost.component';

@NgModule({
  imports: [
    CommonModule,
    BlogpostRoutingModule
  ],
  exports: [
    BlogpostComponent
  ],
  declarations: [BlogpostComponent]
})
export class BlogpostModule { }
