import { NodeStringDecoder } from "string_decoder";

export class Registraion {
    
    name: string;
    email: string;
    password : string;
    

}
