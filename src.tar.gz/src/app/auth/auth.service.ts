import { Injectable } from '@angular/core';import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Registraion } from './registraion';
import { Login } from './login';
import { Data } from '@angular/router';





@Injectable({
  providedIn: 'root'
})
export class AuthService {
  ServerUrl = 'https://f9274e7b.ngrok.io/';
  errorData: {};

  httpOptions = {
    headers: new HttpHeaders({'Content-Type': 'application/json'})
  };

  constructor(private http: HttpClient) { }
  signupForm(data:Registraion):Observable<Registraion> {
    console.log(data)
    return this.http.post<Registraion>(this.ServerUrl + 'users', data, this.httpOptions).pipe(
      catchError(this.handleError)
      
    );
  }

  public login(userInfo: Login){
    localStorage.setItem('ACCESS_TOKEN', "access_token");
  }

  public isLoggedIn(){
    return localStorage.getItem('ACCESS_TOKEN') !== null;

  }

  public logout(){
    localStorage.removeItem('ACCESS_TOKEN');
  }


  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {

    

      console.error('An error occurred:', error.error.message);
    } else {

      

      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }

  

    this.errorData = {
      errorTitle: 'Oops! Request for document failed',
      errorDesc: 'Something bad happened. Please try again later.'
    };
    return throwError(this.errorData);
  }
}
